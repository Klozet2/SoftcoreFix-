# Information
- This is a V1 of an aimbot from clarity
- The aimbot is actually decent, this used to be sold for $100 lifetime and would get buyers 24/7
- It is belived to be pasted from "hollowaim" (not sure if they were the first) and also has chat GPT generated functions and code comments
- The script is probaly pasted as the AI models used are postred on Github for free
- if you dont know how to use the ai aimbot watch the showcase from clarity (https://www.youtube.com/watch?v=ch4iXuz2O4Y)
# Script Details
- Go to line 4963 and enter YOUR keyauth details (https://keyauth.cc/login/)
- Go to lines 4998 and 4904 and enter YOUR webhook URL
- Run 0x.bat and enter a key, should be from YOUR keyauth
# Clarity AI Aimbot Showcases
- https://www.youtube.com/watch?v=L63xuSe10Yk
- https://www.youtube.com/watch?v=ch4iXuz2O4Y
- https://www.youtube.com/watch?v=qdiQnrI0v7Y
